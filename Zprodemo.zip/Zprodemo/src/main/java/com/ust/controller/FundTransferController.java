package com.ust.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.ust.entity.FundTransfer;
import com.ust.model.Response;
import com.ust.service.FundTransferService;

@Controller
public class FundTransferController {

	
	@Autowired
	private FundTransferService fundtransferservice;
	
	@GetMapping(value="/listFundTransfer")
	public ResponseEntity<Response> showlist2(){
	Response response=fundtransferservice.showlist2();
	return new ResponseEntity<Response>(response,HttpStatus.OK);
	
}
	@PostMapping(value="/addFundTransfer")
	public ResponseEntity<Response> addFundTransfer(@RequestBody FundTransfer fundtransfer){
	Response response=fundtransferservice.addFundTransfer(fundtransfer);
	return new ResponseEntity<Response>(response,HttpStatus.OK);
	
}
	
	
	
}
