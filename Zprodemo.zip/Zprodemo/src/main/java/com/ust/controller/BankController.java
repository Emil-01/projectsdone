package com.ust.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.ust.entity.Bank;
import com.ust.model.Response;
import com.ust.service.BankService;

@Controller
public class BankController {

	
	@Autowired
	private BankService bankservice;
	
	@GetMapping(value="/list")
	public ResponseEntity<Response> showlist(){
	Response response=bankservice.showlist();
	return new ResponseEntity<Response>(response,HttpStatus.OK);
	
}
	@PostMapping(value="/addaccount")
	public ResponseEntity<Response> addaccount(@RequestBody Bank bank){
	Response response=bankservice.addaccount(bank);
	return new ResponseEntity<Response>(response,HttpStatus.OK);
	
}
	
	
	@DeleteMapping(value="/deleteaccount")
	public ResponseEntity<Response> deleteaccount(@RequestBody Bank bank){
	Response response=bankservice.deleteaccount(bank);
	return new ResponseEntity<Response>(response,HttpStatus.OK);
	}	
	
	@PutMapping(value="/updateaccount")
	public ResponseEntity<Response> updateaccount(@RequestBody Bank bank){
	Response response=bankservice.updateaccount(bank);
	return new ResponseEntity<Response>(response,HttpStatus.OK);
	}	
}
