package com.ust.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.ust.entity.Customer;
import com.ust.model.Response;
import com.ust.service.CustomerService;

@Controller
public class CustomerController {

	
	@Autowired
	private CustomerService customerservice;
	
	@GetMapping(value="/listcustomers")
	public ResponseEntity<Response> show(){
	Response response=customerservice.show();
	return new ResponseEntity<Response>(response,HttpStatus.OK);
	
}
	@PostMapping(value="/addcustomer")
	public ResponseEntity<Response> addCustomer(@RequestBody Customer customer){
	Response response=customerservice.addCustomer(customer);
	return new ResponseEntity<Response>(response,HttpStatus.OK);
	
}
	
	
	@DeleteMapping(value="/deletecustomer")
	public ResponseEntity<Response> deleteCustomer(@RequestBody Customer customer){
	Response response=customerservice.deleteCustomer(customer);
	return new ResponseEntity<Response>(response,HttpStatus.OK);
	}	
	
	@PutMapping(value="/updatecustomer")
	public ResponseEntity<Response> updateCustomer(@RequestBody Customer customer){
	Response response=customerservice.updateCustomer(customer);
	return new ResponseEntity<Response>(response,HttpStatus.OK);
	}	
}
