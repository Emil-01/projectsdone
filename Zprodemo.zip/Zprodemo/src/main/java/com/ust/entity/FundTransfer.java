package com.ust.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class FundTransfer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long transaction_id;
	private long sender_accountno;
	private long receipient_accountno;
	private String dateof_transaction;
	private long transaction_amount;
	
	
	public long getTransaction_id() {
		return transaction_id;
	}
	public void setTransaction_id(long transaction_id) {
		this.transaction_id = transaction_id;
	}
	public long getSender_accountno() {
		return sender_accountno;
	}
	public void setSender_accountno(long sender_accountno) {
		this.sender_accountno = sender_accountno;
	}
	public long getReceipient_accountno() {
		return receipient_accountno;
	}
	public void setReceipient_accountno(long receipient_accountno) {
		this.receipient_accountno = receipient_accountno;
	}
	public String getDateof_transaction() {
		return dateof_transaction;
	}
	public void setDateof_transaction(String dateof_transaction) {
		this.dateof_transaction = dateof_transaction;
	}
	public long getTransaction_amount() {
		return transaction_amount;
	}
	public void setTransaction_amount(long transaction_amount) {
		this.transaction_amount = transaction_amount;
	}
	

}
