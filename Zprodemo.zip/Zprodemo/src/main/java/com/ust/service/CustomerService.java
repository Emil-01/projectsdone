package com.ust.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.ust.entity.Customer;
import com.ust.model.Response;
import com.ust.repositeries.CustomerRepo;

@Service
public class CustomerService {
	
@Autowired
private CustomerRepo customerrepo;
List<Customer> list1=new ArrayList<>();

public Response show()
{
	list1=customerrepo.findAll();
	Response res=new Response();
	if(!list1.isEmpty()) {
		res.setStatus("The details of accounts are");
		res.setCustomer(list1);
	}else {
		res.setStatus("The details are not available");
		
	}
	return res;
}

public Response addCustomer(Customer customer)
{
	Customer prod =customerrepo.save(customer);
	Response response=new Response();
	if(prod!=null) {
		response.setStatus("The customer is added");
		list1.add(customer);
		response.setCustomer(list1);
	}else
	{response.setStatus("The customer is not created");}
	return response;
}
	

public Response deleteCustomer(Customer customer)
{
	Customer prod=customerrepo.findById(customer.getAccount_no()).get();
	
	Response response=new Response();
	if(prod!=null) {
     customerrepo.delete(customer);
		response.setStatus("The customer is deleted");
		
	}else
	{response.setStatus("The customer is not deleted");
	
}
	return response;
	
}
public Response updateCustomer(Customer customer)
{
	Customer prod=customerrepo.findById(customer.getAccount_no()).get();
	
	Response response=new Response();
	if (null != customer) {
		if (null != customer.getMobile_no()) {
			prod.setMobile_no(customer.getMobile_no());
		}
		if (null != customer.getUserName()) {
			prod.setUserName(customer.getUserName());
		}
		if (null != customer.getPassword()) {
			prod.setPassword(customer.getPassword());
		}
		
	
	customerrepo.save(prod);
	list1.clear();
	list1.add(prod);
	response.setCustomer(list1);
	}
	return response;
}
}






