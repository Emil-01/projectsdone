package com.ust.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.entity.Bank;
import com.ust.model.Response;
import com.ust.repositeries.BankRepo;

@Service
public class BankService {
	
@Autowired
private BankRepo bankrepo;
List<Bank> list1=new ArrayList<>();

public Response showlist()
{
	list1=bankrepo.findAll();
	Response res=new Response();
	if(!list1.isEmpty()) {
		res.setStatus("The details of accounts are");
		res.setBank(list1);
	}else {
		res.setStatus("The details are not available");
		
	}
	return res;
}

public Response addaccount(Bank bank)
{
	Bank prod =bankrepo.save(bank);
	Response response=new Response();
	if(prod!=null) {
		response.setStatus("The account is added");
		list1.add(bank);
		response.setBank(list1);
	}else
	{response.setStatus("The account is not created");}
	return response;
}
	

public Response deleteaccount(Bank bank)
{
	Bank prod=bankrepo.findById(bank.getBranch_Id()).get();
	
	Response response=new Response();
	if(prod!=null) {
     bankrepo.delete(bank);
		response.setStatus("The account is deleted");
		
	}else
	{response.setStatus("The acccount is not deleted");
	
}
	return response;
	
}
public Response updateaccount(Bank bank)
{
	Bank prod=bankrepo.findById(bank.getBranch_Id()).get();
	
	Response response=new Response();
	if(prod!=null) {
    if(null!=bank.getIfsc_code()) {
    prod.setIfsc_code(bank.getIfsc_code());
	}
	if(null!=bank.getLocation()) {
		prod.setLocation(bank.getLocation());
}
	bankrepo.save(prod);
	list1.clear();
	list1.add(prod);
	response.setBank(list1);
	}
	return response;
}
}






