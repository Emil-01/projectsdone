package com.ust.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.datetime.DateFormatter;
import org.springframework.stereotype.Service;

import com.ust.entity.Customer;
import com.ust.entity.FundTransfer;
import com.ust.model.Response;
import com.ust.repositeries.CustomerRepo;
import com.ust.repositeries.FundTransferRepo;

@Service
public class FundTransferService {
	
@Autowired
private FundTransferRepo fundtransferrepo;

@Autowired
private CustomerRepo customerrepo;
List<FundTransfer> list1=new ArrayList<>();

public Response showlist2()
{
	list1=fundtransferrepo.findAll();
	Response res=new Response();
	if(!list1.isEmpty()) {
		res.setStatus("The details of accounts are");
		res.setFundtransfer(list1);
	}else {
		res.setStatus("The details are not available");
		
	}
	return res;
}

public Response addFundTransfer(FundTransfer fundtransfer)
{
	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
	LocalDateTime now = LocalDateTime.now();
	fundtransfer.setDateof_transaction(now.toString());
	FundTransfer prod =fundtransferrepo.save(fundtransfer);
	Response response=new Response();
	if(prod!=null) {
		Customer cust=customerrepo.findById(fundtransfer.getSender_accountno()).get();
		cust.setAccount_balance(cust.getAccount_balance()-fundtransfer.getTransaction_amount());
		customerrepo.save(cust);
		Customer cust1=customerrepo.findById(fundtransfer.getReceipient_accountno()).get();
		cust1.setAccount_balance(cust1.getAccount_balance()+fundtransfer.getTransaction_amount());
		
		
	
		response.setStatus("The customer is added");
		list1.add(prod);
		response.setFundtransfer(list1);
	}else
	{response.setStatus("The customer is not created");
	list1.add(fundtransfer);
	response.setFundtransfer(list1);
	}
	return response;
}
}
	

