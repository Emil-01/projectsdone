package com.app.model;

public class Employee {
private int emplid;
private String empName;
private double empSal;
public int getEmplid() {
	return emplid;
}
public void setEmplid(int emplid) {
	this.emplid = emplid;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public double getEmpSal() {
	return empSal;
}
public void setEmpSal(double empSal) {
	this.empSal = empSal;
}
@Override
public String toString() {
	return "Employee [emplid=" + emplid + ", empName=" + empName + ", empSal=" + empSal + "]";
}

}
