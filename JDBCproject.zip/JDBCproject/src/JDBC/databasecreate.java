package JDBC;

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class databasecreate {
	static final String DB_URL ="jdbc:mysql://localhost:3306/ICICBANK";
	static final String USER ="root";
	static final String PASSWORD ="root";
	public static void main(String args[])throws SQLException
	{
		 
			  
			Connection c=DriverManager.getConnection(DB_URL,USER,PASSWORD); 
	
			 
			Statement stmt=c.createStatement();
					
			//String sql="create database ICICBANK" ;
			//stmt.executeUpdate(sql); 
			//System.out.println("Database created");
			String sql1 = "create table customer_details" +
					"(id int not null auto_increment primary key," +
					"name varchar(50),age int not null)";
	stmt.executeUpdate(sql1);
	System.out.println("customer_details created successfully....");
					}
			 
	}

