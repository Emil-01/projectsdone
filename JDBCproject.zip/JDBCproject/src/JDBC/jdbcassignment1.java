package JDBC;
import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class jdbcassignment1 {

	static final String DB_URL = "jdbc:mysql://localhost:3306/ICICBANK";
	static final String USER = "root";
	static final String PASS = "root";
	public static void main(String[] args) throws SQLException
	{
			
		Connection c=DriverManager.getConnection(DB_URL,USER,PASS);
				Statement s=c.createStatement();
				String sql1="create database ICICBANK" ;
				s.executeUpdate(sql1); 
				System.out.println("Database created");
				String sql2 = "create table customer_details" +
					"(id int not null auto_increment primary key, name varchar(50), age int not null)";
				 s.executeUpdate(sql2);
			Scanner scanner = new Scanner(System.in);	
			System.out.println("Enter you name: ");
			String name = scanner.nextLine();
			System.out.println("Enter you age: ");
			int age = scanner.nextInt();
			if(age<18) {
				System.out.println("Not able to open account ");
			}
			else {
				String sql3 = "insert into customer_details (name, age) values " + "( '" + name + " ',"+ age + ")";
				
						s.executeUpdate(sql3);
				
				System.out.println("records inserted");}
				
				ResultSet rs=s.executeQuery("select * from customer_details");  
				while(rs.next())  
				System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3));  
				
				//c.close();	
				scanner.close();
	}

}
