import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
public class Product {
	int id;
	String name;
	double price;
	public Product(int id,String name,double price)
	{super();
		this.id=id;
		this.name=name;
		this.price=price;
	}
	
public class demo{
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	List<Product>list=new ArrayList<>();
	List<Double>pricelist=new ArrayList<>();
	list.add(new Product(10,"EMIL",1293.0));
	list.add(new Product(11,"REIL",14353.0));
	list.add(new Product(12,"MELWIN",23423.0));
	pricelist=list.stream()
			.filter(p->p.price>1000)
			.map(p->p.price)
			.collect(Collectors.toList());
			System.out.println(pricelist);
	

	}

}
}
