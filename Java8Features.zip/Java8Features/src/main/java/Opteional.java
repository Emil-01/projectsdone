import java.util.Optional;
public class Opteional {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   String str[]=new String[10];
   Optional<String>checkNullable=Optional.ofNullable(str[5]);
		   checkNullable.ifPresent(System.out::print);
	}

}
