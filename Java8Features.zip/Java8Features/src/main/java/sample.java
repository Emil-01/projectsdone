import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.time.*;
public class sample {

	public static void main(String[] args) {
		List<Integer> values=Arrays.asList(4,5,6,7,8);
		values.forEach(i->System.out.println(i));
LocalDate d=LocalDate.now();
System.out.println(d);
	}

}
