package com.ust.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table
public class FundTransfer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long transaction_Id;
	@JoinColumn
	(referencedColumnName="Account_no")
	private String Account_no;
	
	private String recipient_accountno;
	private String dateof_transaction;
	private double transaction_amount;
	@ManyToOne
	(cascade=CascadeType.ALL)
	private Customer customer;
	public long getTransaction_Id() {
		return transaction_Id;
	}
	public void setTransaction_Id(long transaction_Id) {
		this.transaction_Id = transaction_Id;
	}
	public String getAccount_no() {
		return Account_no;
	}
	public void setAccount_no(String account_no) {
		Account_no = account_no;
	}
	public String getRecipient_accountno() {
		return recipient_accountno;
	}
	public void setRecipient_accountno(String recipient_accountno) {
		this.recipient_accountno = recipient_accountno;
	}
	public String getDateof_transaction() {
		return dateof_transaction;
	}
	public void setDateof_transaction(String dateof_transaction) {
		this.dateof_transaction = dateof_transaction;
	}
	public double getTransaction_amount() {
		return transaction_amount;
	}
	public void setTransaction_amount(double transaction_amount) {
		this.transaction_amount = transaction_amount;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	@Override
	public String toString() {
		return "FundTransfer [transaction_Id=" + transaction_Id + ", Account_no=" + Account_no
				+ ", recipient_accountno=" + recipient_accountno + ", dateof_transaction=" + dateof_transaction
				+ ", transaction_amount=" + transaction_amount + ", customer=" + customer + "]";
	}
	

}
