package com.ust.controller;
import org.hibernate.loader.plan.exec.process.spi.ReturnReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ust.entity.Bank;
import com.ust.model.Response;
import com.ust.service.BankService;

@RestController
@RequestMapping(value = "/bank")
public class BankController {
	@Autowired
	private BankService bankService;
	
	@GetMapping(value = "/list")
	public ResponseEntity<Response> showList(){
		Response response=bankService.showList();
		return new ResponseEntity<Response>(response ,HttpStatus.OK);
		
	}
	@PostMapping(value = "/addBank")
	public ResponseEntity<Response> addBank(@RequestBody Bank bank){
		Response response=bankService.addBank(bank);
		return new ResponseEntity<Response>(response ,HttpStatus.OK);
		
	}
	@DeleteMapping(value = "/deleteBank")
	public ResponseEntity<Response> deleteBank(@RequestBody Bank bank){
		Response response=bankService.deleteBank(bank);
		return new ResponseEntity<Response>(response ,HttpStatus.OK);
		
	}
	@PutMapping(value = "/updateBank/{id}")
	public ResponseEntity<Response> updateBank(@PathVariable("id") Integer Branch_Id){
		Response response=bankService.updateBank( Branch_Id);
		return new ResponseEntity<Response>(response ,HttpStatus.OK);
		
	}
	
	

}
