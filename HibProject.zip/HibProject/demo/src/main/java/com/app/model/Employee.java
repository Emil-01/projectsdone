package com.app.model;

public class Employee {
 private int eid;
 private String eName;
 private double eSal;
public int getEid() {
	return eid;
}
public void setEid(int eid) {
	this.eid = eid;
}
public String geteName() {
	return eName;
}
public void seteName(String eName) {
	this.eName = eName;
}
public double geteSal() {
	return eSal;
}
public void seteSal(double eSal) {
	this.eSal = eSal;
}
@Override
public String toString() {
	return "Employee [eid=" + eid + ", eName=" + eName + ", eSal=" + eSal + "]";
}
 
}
