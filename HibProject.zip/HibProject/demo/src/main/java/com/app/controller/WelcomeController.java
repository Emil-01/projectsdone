package com.app.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.model.Employee;

@RestController
public class WelcomeController {
	
	@GetMapping("/")
	public String welcomeMsg() {
		return "welcome to spring boot application";
	}
	
	@GetMapping("/vote")
	public String welcome(@RequestParam String name,@RequestParam int age) {
		if(age>18)
		return "you are eligible to vote " +name;
		else
			return "you are not eligible to vote " +name;
	}
	
	@GetMapping("/emp")
	public Employee empInfo()  {
		Employee emp=new Employee();
		emp.setEid(101);
		emp.seteName("Kunal");
		emp.seteSal(1230.89);
		
		return emp;
		
	}
	@PostMapping("/addemp")
	public Employee addEmp(@RequestBody Employee emp)  {
		
		return emp;
		
	}
}
