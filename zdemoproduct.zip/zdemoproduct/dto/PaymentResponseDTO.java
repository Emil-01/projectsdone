package com.ust.dto;

public class PaymentResponseDTO {
private String name;
private double price;
private String Status;

}
