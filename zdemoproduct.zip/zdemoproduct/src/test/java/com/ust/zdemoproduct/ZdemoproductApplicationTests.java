package com.ust.zdemoproduct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZdemoproductApplicationTests {

	@Test
	void contextLoads() {
	}

}
