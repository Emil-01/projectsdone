package com.ust.controller;

import org.hibernate.loader.plan.exec.process.spi.ReturnReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ust.entity.Product;
import com.ust.model.Response;
import com.ust.service.ProductService;

@Controller
@RequestMapping(value="/product")
public class ProductController {

@Autowired
private ProductService productservice;
	
@GetMapping(value="/show")
public ResponseEntity<Response> showlist()
{
Response response=productservice.showlist();
return new ResponseEntity<Response>(response,HttpStatus.OK);
}

@PostMapping(value="/add")
public ResponseEntity<Response> addlist(@RequestBody Product product)
{
Response response=productservice.addlist( product);
return new ResponseEntity<Response>(response,HttpStatus.OK);
}
@DeleteMapping(value="/delete")
public ResponseEntity<Response> deletelist(@RequestBody Product product)
{
Response response=productservice.deletelist( product);
return new ResponseEntity<Response>(response,HttpStatus.OK);
}
}