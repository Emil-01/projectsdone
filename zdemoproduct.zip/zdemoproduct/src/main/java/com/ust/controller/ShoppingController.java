package com.ust.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ust.dto.PaymentRequestDTO;
import com.ust.dto.PaymentResponseDTO;
import com.ust.entity.Product;
import com.ust.model.Response;
import com.ust.service.PaymentService;
import com.ust.service.ProductService;
@RestController
public class ShoppingController {

	@Autowired
	private PaymentService paymentservice;
	@PostMapping(value="/buyProduct")
	public ResponseEntity<PaymentResponseDTO> buyProduct(@RequestBody PaymentRequestDTO product){
	PaymentResponseDTO response=paymentservice.buyProduct(product);
	
	return new ResponseEntity<PaymentResponseDTO>(response,HttpStatus.OK);
	
}
}
