package com.ust.dto;

public class PaymentRequestDTO {
	private String pname;
	private double price;
	private long accountnumber;
	
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public long getAccountnumber() {
		return accountnumber;
	}
	public void setAccountnumber(long accountnumber) {
		this.accountnumber = accountnumber;
	}
	@Override
	public String toString() {
		return "PaymentRequestDTO [pname=" + pname + ", price=" + price + ", accountnumber=" + accountnumber + "]";
	}
	
	

}
