package com.ust.dto;

public class AccountRequestDTO {
private long accountnumber;
private double amount;

public long getAccountnumber() {
	return accountnumber;
}
public void setAccountnumber(long accountnumber) {
	this.accountnumber = accountnumber;
}
public double getAmount() {
	return amount;
}
public void setAmount(double amount) {
	this.amount = amount;
}
@Override
public String toString() {
	return "AccountRequestDTO [accountnumber=" + accountnumber + ", amount=" + amount + "]";
}



}