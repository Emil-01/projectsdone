package com.ust.dto;

public class PaymentResponseDTO {
private String pname;
private double price;
private String Status;

public String getPname() {
	return pname;
}
public void setPname(String pname) {
	this.pname = pname;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
public String getStatus() {
	return Status;
}
public void setStatus(String status) {
	Status = status;
}
@Override
public String toString() {
	return "PaymentResponseDTO [pname=" + pname + ", price=" + price + ", Status=" + Status + "]";
}


}
