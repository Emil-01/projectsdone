package com.ust.service;



import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.entity.Product;
import com.ust.model.Response;
import com.ust.repositories.ProductRepo;




@Service
public class ProductService {
	
	@Autowired
	private ProductRepo repo;
	List<Product> list=new ArrayList<>();
	
	public Response showlist() {
	list=repo.findAll();
	Response response=new Response();
	if(!list.isEmpty())
	{
		response.setStatus("updted data");
		response.setProduct(list);
		
	}else {
		response.setStatus( "not updated");
	}
	return response;	
	}

	public Response addlist(Product product) {
	Product p=repo.save(product);
	Response response=new Response();
	if(p!=null)
	{
		response.setStatus("updted data");
		list.add(p);
		response.setProduct(list);
		
	}else {
		response.setStatus( "not updated");
	}
	return response;	
	}
	public Response deletelist(Product product) {
		Product p=repo.findById(product.getPid()).get();
		
		
		Response response=new Response();
		if(p!=null)
		{
			repo.delete(product);
			response.setStatus("deleted sucessfully");
			
			
			
		}else {
			response.setStatus( "not updated");
		}
		return response;	
		}

}
