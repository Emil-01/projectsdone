package com.ust.service;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.ust.dto.AccountRequestDTO;
import com.ust.dto.AccountResponseDTO;
import com.ust.dto.PaymentRequestDTO;
import com.ust.dto.PaymentResponseDTO;

@Service
public class PaymentService {

	public PaymentResponseDTO buyProduct(PaymentRequestDTO product) {
	RestTemplate restTemplate=new RestTemplate();
	final String url="http://localhost:9101/payment";
	AccountRequestDTO request=new AccountRequestDTO();
	request.setAccountnumber(product.getAccountnumber());
	request.setAmount(product.getPrice());
	ResponseEntity<AccountResponseDTO> response=restTemplate.postForEntity(url,request,AccountResponseDTO.class);
	PaymentResponseDTO dto=new PaymentResponseDTO();
	if(response.getBody().getStatus().equalsIgnoreCase("SUCCESS"))
	{
		dto.setPname(product.getPname());
		dto.setPrice(product.getPrice());
		dto.setStatus("we will deliver it within 1 week");
	}else
	{
		dto.setPname(product.getPname());
		dto.setPrice(product.getPrice());
		dto.setStatus("payment can't be made");	
	}
	return dto;
}
}
