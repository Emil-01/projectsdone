package com.app;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;

@Entity
@Table
public class Bank {
	@Id
	private String Branch_Id;
	private String Branch_name;
	private String location;
	private String IFSC_code;
	@OneToMany(mappedBy="bank",cascade=CascadeType.ALL)
	private List<Customer> customer = new ArrayList();
	public String getBranch_Id() {
		return Branch_Id;
	}
	public void setBranch_Id(String branch_Id) {
		Branch_Id = branch_Id;
	}
	public String getBranch_name() {
		return Branch_name;
	}
	public void setBranch_name(String branch_name) {
		Branch_name = branch_name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getIFSC_code() {
		return IFSC_code;
	}
	public void setIFSC_code(String iFSC_code) {
		IFSC_code = iFSC_code;
	}
	public List<Customer> getCustomer() {
		return customer;
	}
	public void setCustomer(List<Customer> customer) {
		this.customer = customer;
	}
	
	
	

}
