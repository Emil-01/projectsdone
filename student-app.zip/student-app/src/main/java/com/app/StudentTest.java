package com.app;

import java.lang.module.Configuration;

import com.app.model.Student;

public class StudentTest {
	public static void main(String[] args)
	Configuration config=new Configuration();
	config.configure("application-cfg.xml");
	SessionFactory factory=config.buildSessionFactory();
	Session session=factory.openSession();
	Transaction tx=session.beginTransaction();
	List<Student> list=new ArrayList<Student>();
	Student st=new Student();
	st.setstudid(102);
	st.setname("Priya Kolhe");
	st.setaddress("Mumbai");
	session.save(st);
	tx.commit();
	System.out.println("Data Stored Successfully...!");

}
