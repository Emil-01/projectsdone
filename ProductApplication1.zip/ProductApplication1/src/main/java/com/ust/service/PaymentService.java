package com.ust.service;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;

import com.ust.dto.AccountRequestDTO;
import com.ust.dto.AccountResponseDTO;
import com.ust.dto.PaymentRequestDTO;
import com.ust.dto.PaymentResponseDTO;

@Service
public class PaymentService {

	public PaymentResponseDTO buyProduct(PaymentRequestDTO product) {
		// TODO Auto-generated method stub
		RestTemplate restTemplate=new RestTemplate();
		final String url="http://localhost:9009/payment";
		AccountRequestDTO request=new AccountRequestDTO();
		request.setAccountNumber(product.getBankAccNumber());
		request.setAmount(product.getPrice());
		ResponseEntity<AccountResponseDTO> response=restTemplate.postForEntity(url, request, AccountResponseDTO.class);
		PaymentResponseDTO dto=new PaymentResponseDTO();
		if(response.getBody().getStatus().equalsIgnoreCase("SUCCESS")) {
			dto.setName(product.getName());
			dto.setPrice(product.getPrice());
			dto.setStatus("Your Product order done ,we  deliver your order within 7 days...");
		}
		else {
			dto.setName(product.getName());
			dto.setPrice(product.getPrice());
			dto.setStatus("we facing payment issue please check your bank details...");
		}
		return dto;
	}
	

}
