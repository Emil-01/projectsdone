package com.ust.service;



import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.entity.Product;
import com.ust.model.Response;
import com.ust.repositories.ProductRepo;



@Service
public class ProductService {

	@Autowired
	private ProductRepo repo;
	List<Product> list=new ArrayList<>();
	public Response productList() {
		// TODO Auto-generated method stub
		
		list=repo.findAll();
		Response res=new Response();
		if(!list.isEmpty()) {
			res.setStatus("Below List of Product Avilable In DB");
			res.setProduct(list);
		}
		else {
			res.setStatus("list is empty..!");
		}
		return res;
	}
	public Response addProduct(Product product) {
		// TODO Auto-generated method stub
		Product prod=repo.save(product);
		Response response=new Response();
		if(prod!=null) {
			response.setStatus("Product Added in DB Sussfully...!");
			list.add(prod);
			response.setProduct(list);
		}else {
			response.setStatus("Product  Not Added in DB ...!");
		list.add(product);
		response.setProduct(list);
	}
		return response;
	}
	public Response deleteProduct(Product product) {
		// TODO Auto-generated method stub
		Product p=repo.findById(product.getPid()).get();
		Response response=new Response();
		if(p!=null) {
		repo.deleteById(product.getPid());
		
		}
		else {
			response.setStatus("Data Not Avilable in DB ...!");
		}
		return response;
	}
	public Response updateProduct(Product product) {
		// TODO Auto-generated method stub
		Product p=repo.findById(product.getPid()).get();
		Response response=new Response();
		if(p!=null) {
			p.setName("Camera");
			p.setPid(product.getPid());
			repo.save(p);
			
				response.setStatus("Data Updated Successfully in DB ...!");
				list.clear();
				list.add(p);
				response.setProduct(list);
			
			
		}
		else {
			response.setStatus("Data Not Avilable in DB ...!");
		}
		return response;
	}

}
