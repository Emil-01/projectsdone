package com.app.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.model.Employee;

@RestController
public class EmployeeController {
	@GetMapping("/employee")
	public Employee getEmployee() {
		Employee emp=new Employee();
		emp.setEmpId(101);
		emp.setEmpName("Raj Kolhe");
		emp.setEmpSal(12920.90);
		return emp;
	}

}
