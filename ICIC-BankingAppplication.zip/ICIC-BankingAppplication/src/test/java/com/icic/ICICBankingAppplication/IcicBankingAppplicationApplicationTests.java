package com.icic.ICICBankingAppplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IcicBankingAppplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
