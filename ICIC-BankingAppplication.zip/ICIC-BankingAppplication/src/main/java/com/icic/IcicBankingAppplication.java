package com.icic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IcicBankingAppplication {

	public static void main(String[] args) {
		SpringApplication.run(IcicBankingAppplication.class, args);
	}

}
