package com.icic.model;

public class Account {

}
