package com.ust.controller;

import org.hibernate.loader.plan.exec.process.spi.ReturnReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ust.entity.Product;
import com.ust.model.Response;
import com.ust.service.ProductService;

@RestController
@RequestMapping(value = "/product")
public class ProductController {

	@Autowired
	private ProductService productService;
	
	@GetMapping(value = "/list")
	public ResponseEntity<Response> productList(){
		Response response=productService.productList();
		return new ResponseEntity<Response>(response ,HttpStatus.OK);
		
	}
	@PostMapping(value = "/addProduct")
	public ResponseEntity<Response> addProduct(@RequestBody Product product){
		Response response=productService.addProduct(product);
		return new ResponseEntity<Response>(response ,HttpStatus.OK);
		
	}
	@DeleteMapping(value = "/delete")
	public ResponseEntity<Response> deleteProduct(@RequestBody Product product){
		Response response=productService.deleteProduct(product);
		return new ResponseEntity<Response>(response ,HttpStatus.OK);
		
	}
}
