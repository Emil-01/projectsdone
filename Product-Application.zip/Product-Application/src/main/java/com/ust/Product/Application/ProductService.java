package com.ust.Product.Application;

import org.apache.catalina.connector.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductService {
  
	
	
	@Autowired
	private ProductRepo repo:
		List<Product> list=new ArrayList<>();
	public Response productList() {
		
		list=repo.findAll();
		Response res=new Response();
		if(!list.isEmpty()) {
			res.setStatus("Below list of Product available in DB");
			res.setProduct(list);
		}
		else {
			res.setStatus("list is empty...!");
			
		}
		return res;
	}
	public Response addProduct(Product product) {
		Product prod=repo.save(product);
		Response response=new Response();
		if(prod!=null) {
			response.setStatus("Product added in DB Sussfully");
			list.add(prod);
			respose.setProduct(list);
		}else {
			response.setStatus("Product not in DB...!");
			
		}
	}
}
