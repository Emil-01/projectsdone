package com.ust.model;

public class Response {
	private String status;
	private List<Product> product;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public List<Product> getProduct() {
		return product;
	}
	public void setProduct(List<Product> product) {
		this.product = product;
	}
	@Override
	public String toString() {
		return "Response [status=" + status + "]";
	}
	

}
