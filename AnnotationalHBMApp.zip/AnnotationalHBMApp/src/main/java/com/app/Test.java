package com.app;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration config=new Configuration();
		config.configure("application-cfg.xml");
		SessionFactory factory=config.buildSessionFactory();
		Session session=factory.openSession();
		Transaction tx=session.beginTransaction();
		Employee emp=new Employee();
		emp.setEmpId(101);
		emp.setEmpName("Kiran");
		emp.setSalary(1273.90);
		session.persist(emp);
		tx.commit();
		System.out.println("data Added...!");
		session.close();

	}

}
