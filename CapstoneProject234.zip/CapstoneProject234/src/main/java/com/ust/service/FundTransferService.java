package com.ust.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.entity.Customer;
import com.ust.entity.FundTransfer;
import com.ust.model.Response;
import com.ust.repositories.CustomerRepo;
import com.ust.repositories.FundTransferRepo;

@Service
public class FundTransferService {

	@Autowired
	private FundTransferRepo repo;
	
	@Autowired
	private CustomerRepo custRepo; 
	
	List<FundTransfer> list3 =new ArrayList<>();
	
	public Response showList(FundTransfer fundTransfer) {
		list3=repo.findAll();
		List<FundTransfer> resultList =new ArrayList<>();
		Response res=new Response();
		if(!list3.isEmpty()) {
			for(FundTransfer ls : list3 ) {
				if(ls.getSender_accountno() == fundTransfer.getSender_accountno()||ls.getRecipient_accountno()==fundTransfer.getSender_accountno()) {
					resultList.add(ls);
				}
			}
			res.setStatus("Transaction details");
			res.setFundtransfer(resultList);
		}
		else {
			res.setStatus("list is empty..!");
		}
		return res;
	}

	public Response addFundTransfer(FundTransfer fundTransfer) {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		fundTransfer.setDateof_transaction(now.toString());
		FundTransfer prod = repo.save(fundTransfer);
		Response response = new Response();
		if (prod != null) {
			Customer sendCustomer = custRepo.findById(fundTransfer.getSender_accountno()).get();
			sendCustomer.setAccount_Balance(sendCustomer.getAccount_Balance() - fundTransfer.getTransaction_amount());
			custRepo.save(sendCustomer);
			Customer recCustomer = custRepo.findById(fundTransfer.getRecipient_accountno()).get();
			recCustomer.setAccount_Balance(recCustomer.getAccount_Balance()+fundTransfer.getTransaction_amount());
			custRepo.save(recCustomer);
			response.setStatus("Data Added in DB Successfully...!");
			list3.add(prod);
			response.setFundtransfer(list3);
		} else {
			response.setStatus("Data Not Added in DB ...!");
			list3.add(fundTransfer);
			response.setFundtransfer(list3);
		}
		return response;
	}
	/*public Response deleteFundTransfer(FundTransfer fundTransfer) {
		// TODO Auto-generated method stub
		FundTransfer p=repo.findById(fundTransfer.getAccount_no()).get();
		Response response=new Response();
		if(p!=null) {
		repo.delete(fundTransfer);
		response.setStatus("Data Deleted Successfully...!");
		}
		else {
			response.setStatus("Data Not Avilable in DB ...!");
		}
		return response;
	}*/

}
