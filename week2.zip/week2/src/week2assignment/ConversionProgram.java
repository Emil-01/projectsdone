package week2assignment;

import java.util.*;

public class ConversionProgram {
	public static void main(String args[]){  
	Scanner sn=new Scanner(System.in); 
	System.out.println("Enter a number");
	 double d=sn.nextDouble();  
	int i=(int)d;  
	System.out.println(i);  
		}}  

