package week2assignment;

import static org.junit.Assert.*;

import org.junit.Test;

public class Week4 {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
