package week2project;
import java.io.File;
class DeleteFile2 {
	public static void main(String[] args) {
		 
	    // creates a file object
	    File file = new File("D:filename.txt");
	 
	    // deletes the file
	    boolean value = file.delete();
	    if(value) {
	      System.out.println("filename.txt is successfully deleted.");
	    }
	    else {
	      System.out.println("File doesn't exit");
	    }
	  }

}
