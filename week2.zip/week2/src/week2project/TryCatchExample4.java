package week2project;

public class TryCatchExample4 {
	public static void main(String[] args) {  
          
        int data=50/0; //may throw exception   
        
        System.out.println("rest of the code");  
    }  

}
