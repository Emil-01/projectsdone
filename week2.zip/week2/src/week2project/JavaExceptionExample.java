package week2project;
import com.sun.source.tree.CatchTree;
public class JavaExceptionExample {
	public static void main(String[] args) {  
		  
	        try  
	        {  
	        int data=50/0; //may throw exception   
	        }  
	            // handling the exception by using Exception class      
	        catch(ArithmeticException e)  
	        {  
	            System.out.println(e);  
	        }  
	        System.out.println("rest of the code");  
	      
		 try  
	        {  
	        String s= null; //may throw exception   
	        System.out.println(s.length());   
	        }  
	            // handling the exception by using Exception class      
	        catch(NullPointerException f)  
	        {  
	            System.out.println(f);  
	        }  
		 try  
	        {  
	        String s="abc"; //may throw exception   
	        int i=Integer.parseInt(s) ;
	        }  
	            // handling the exception by using Exception class      
	        catch(NullPointerException f)  
	        {  
	            System.out.println(f);  
	        }   
	} 
 
    }  
     

