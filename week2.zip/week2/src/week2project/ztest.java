package week2project;

import java.util.Scanner;

public class ztest {
	public static void main(String args[]) {
	BankAccount1 obj=new BankAccount1("emil","1245");
			obj.show();
}
}
	
	class BankAccount1{
    int bal;
    int previousTransaction;
	String accnumber;
	String customername;
	
	BankAccount1(String custname,String accNo)
	{accnumber=accNo;
	customername=custname;
	
	}
	void deposit(int amount) {
		bal=+amount;
		previousTransaction=amount;
	}
	void withdraw(int amount) {
		bal=-amount;
		previousTransaction=-amount;
	}
	void getpreviousTransaction()
	{if(previousTransaction>0)
	{System.out.println("Deposited amount is: " +previousTransaction);
	}else if(previousTransaction<0) {
		System.out.println("Withdrawn amount is: " +Math.abs(previousTransaction));
		
	}
	else {
		System.out.println("No action is preformed");
	}
	}
	void show()
	{
		char option='\0';
		Scanner scanner=new Scanner(System.in);
		System.out.println("Entera opton here " );
		System.out.println("A.Show account " );
		System.out.println("B.Deposit " );
		System.out.println("C.Withdraw " );
		System.out.println("D.Previous transaction " );
		System.out.println("E.Exit " );
		
		do {
			System.out.println("Enter a opton here " );
		
		 option=scanner.next().charAt(0);
		
		switch(option)
		{
		case 'A':
			System.out.println("Your balance is " +bal );
			
		break;
		case 'B':
			System.out.println("Deposit is "  );
			int amount=scanner.nextInt();
			deposit(amount);
			
		break;
		case 'C':
			System.out.println("Withdrawn amount is "  );
			int amount2=scanner.nextInt();
			withdraw(amount2);
			
		break;
		case 'D':
			System.out.println("Previous Transaction "  );
			//int amount=scanner.nextInt();
			getpreviousTransaction();
			
		break;
		case 'E':
			System.out.println("Ecited "  );
			;
			
		break;
		default:
			System.out.println("Invalid operation"  );
		}}
		while(option!='E'); {
			System.out.println("Thank you for your services"  );
			
		}
		}}
		
		
		
		
