package Design;
interface Prototype {  
	  
    public Prototype getClone();  
     
}
